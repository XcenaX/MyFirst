﻿using System;
using System.Collections.Generic;
using System.Text;
//1.	Написать приложение, которое выведет на экран Ваше имя и фамилию.
//2.	Написать приложение, которое ожидает ввода нескольких чисел и выводит на экран их сумму.

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args){
            Console.WriteLine("Введите ваше Имя : ");
            string FirstNameOfUser = Console.ReadLine();

            Console.WriteLine("Введите вашу Фамилию : ");
            string LastNameOfUser = Console.ReadLine();

            Console.Write("\nВаше Имя : " + FirstNameOfUser);
            Console.Write("\nВаша Фамилия : " + LastNameOfUser + "\nНажмите любую кнопку.  .  .");
            Console.ReadKey();
            Console.Clear();
            int FirstNumber , SecondNumber;
            Console.WriteLine("А теперь введите два числа для сложения");
            InputNumbers:
            try
            {
                Console.Write("Первое число : ");
               if(( FirstNumber = Convert.ToInt32(Console.ReadLine())) == null) throw new System.FormatException();
                
                Console.Write("\n Второе число : ");
               if( (SecondNumber = Convert.ToInt32(Console.ReadLine())) == null) throw new System.FormatException();
            }

            catch (System.FormatException){
                Console.Clear();
                Console.WriteLine("Вы ввели не число! Введите число заного : ");
                goto InputNumbers;
            }

            Console.Write("Сумма сложения чисел = " + (FirstNumber + SecondNumber) + "\nНажмите любую кнопку .  .  .");
            Console.ReadKey();
        }
    }
}